import json

training_blocks = [

    {
        "intent": "definition",
        "queries": [
            "what is osmosis",
            "define osmosis",
            "explain what osmosis is"
        ],
        "positive": 
            "Osmosis is the movement of water molecules through a semi-permeable membrane.",
        "negatives": [
            "Osmosis makes plant cells firm and provides support to the plant.",
            "Plants absorb water from the soil by osmosis through root hair cells.",
            "Osmosis maintains the correct water balance in animal cells."
        ]
    },

    {
        "intent": "definition_membrane",
        "queries": [
            "what is a semi-permeable membrane",
            "define semi-permeable membrane",
            "explain what a semi-permeable membrane is"
        ],
        "positive": 
            "A semi-permeable membrane allows water molecules to pass through but restricts other molecules.",
        "negatives": [
            "Osmosis is the movement of water molecules through a semi-permeable membrane.",
            "Plants absorb water from the soil by osmosis through root hair cells.",
            "Osmosis makes plant cells firm and provides support to the plant."
        ]
    },

    {
        "intent": "importance_bacteria",
        "queries": [
            "what is the importance of osmosis in bacteria",
            "explain the importance of osmosis in bacteria",
            "state the importance of osmosis in bacterial cells"
        ],
        "positive": 
            "The cell wall prevents bacterial cells from bursting when they absorb excess water by osmosis.",
        "negatives": [
            "Osmosis is the movement of water molecules through a semi-permeable membrane.",
            "Osmosis makes plant cells firm and provides support to the plant.",
            "Plants absorb water from the soil by osmosis through root hair cells."
        ]
    },

    {
        "intent": "importance_plants",
        "queries": [
            "how does osmosis help plants",
            "why is osmosis important for plant support",
            "explain how osmosis makes plant cells firm"
        ],
        "positive": 
            "Osmosis makes plant cells firm and provides support to the plant.",
        "negatives": [
            "Osmosis is the movement of water molecules through a semi-permeable membrane.",
            "Plants absorb water from the soil by osmosis through root hair cells.",
            "Osmosis maintains the correct water balance in animal cells."
        ]
    },

    {
        "intent": "absorption_plants",
        "queries": [
            "how do plants absorb water from the soil",
            "role of osmosis in water absorption in plants",
            "explain how root hair cells use osmosis"
        ],
        "positive": 
            "Plants absorb water from the soil by osmosis through root hair cells.",
        "negatives": [
            "Osmosis is the movement of water molecules through a semi-permeable membrane.",
            "Osmosis makes plant cells firm and provides support to the plant.",
            "Osmosis maintains the correct water balance in animal cells."
        ]
    },

    {
        "intent": "importance_animals",
        "queries": [
            "why is osmosis important in animal cells",
            "how does osmosis affect animal cells",
            "explain the importance of osmosis in animals"
        ],
        "positive": 
            "Osmosis maintains the correct water balance in animal cells, preventing them from bursting or shrinking.",
        "negatives": [
            "Osmosis is the movement of water molecules through a semi-permeable membrane.",
            "Osmosis makes plant cells firm and provides support to the plant.",
            "Plants absorb water from the soil by osmosis through root hair cells."
        ]
    }
]

try:
    with open("training_data.json", "w", encoding="utf-8") as file:
        json.dump(training_blocks, file, ensure_ascii=False)
        
except Exception as e:
    print("Error loading file:", e)  

with open("training_data.json", "r", encoding="utf-8") as file:
    training_blocks = json.load(file)

processed_blocks = []

for block in training_blocks:
    intent = block["intent"].replace("_", " ").capitalize()
    
    processed_block = {
        "intent": block["intent"],
        "queries": block["queries"],
        "positive": f"{intent}: {block['positive']}",
        "negatives": block["negatives"]
    }
    
    processed_blocks.append(processed_block)

with open("training_data_intent_aware.json", "w", encoding="utf-8") as file:
    json.dump(processed_blocks, file, indent=4, ensure_ascii=False)

print("Intent-aware training data saved.")                