import json
import os


with open("SBERT-rawdata.json", "r", encoding="utf-8") as f:
    data = json.load(f)   # JSON → Python dict

with open("SBERT-rawdata_pretty.json", "w", encoding="utf-8") as f:
    json.dump(
        data,
        f,
        indent=4,
        ensure_ascii=False
    )

print("JSON reformatted and saved.")

with open("training_data.json", "r", encoding="utf-8") as f:
    data_block = json.load(f)

data = {}
data_queries = [] 
data_positive = [] 
                        
for block in data_block:
    positive = block["positive"]
    queries = block["queries"]
    data_queries.append(queries)
    data_positive.append(positive)

print(data_queries)                                            
for queries, positive in zip(data_queries, data_positive):
    if isinstance(queries, list):
        for query in queries:
            data[query]=positive 
    else:            
        data[queries]=positive
    
print("\n\n\n\n\n", data) 

try:
    if not os.path.exists("OsmosisFacts.json"):
        with open("OsmosisFacts.json", "w", encoding="utf-8") as f:
            json.dump(data, f, indent=4, ensure_ascii=False) 
            print("created response.json ✅")
except Exception as e:
    print("Error ❌ loading response.json:", e)                         
                  