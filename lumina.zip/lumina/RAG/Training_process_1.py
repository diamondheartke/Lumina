import json

data_file = "training_data.json"

try:
    with open(data_file, "r", encoding='utf-8') as file:
        raw_data = json.load(file)
        print("Loaded data from json")

except Exception as e:
    print("Error loading json data:", e) 
  
data_samples = [] 
           
for data in raw_data:
    queries = data["queries"]
    positives = data["positive"]
    negatives = data["negatives"]  
    for query in queries:
        for negative in negatives:
            data_samples.append((f'query: {query}', positives,  f'negative: {negative}'))                                                     
#for sample in data_samples:   
   # print(sample)     
   
print("len(data_samples))                                                                                                         