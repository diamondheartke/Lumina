import json
import os 
from chatbot import ChatBot
from token_simulation import TokenSimulation
import random

OsmosisFacts = "Database/Bot/OsmosisFacts.json"
ResponseFile = "Database/Bot/response.json" 

class MainLoop:
    def __init__(self, bot="lumina", db="Database/Bot/response.json", fact_file="Database/Bot/OsmosisFacts.json"):
        self.db = db
        
        self.bot=bot
        
        self.Lumina = Lumina
        
        Lumina = ChatBot(name="Lumina", fact_file=OsmosisFacts, response_file=db)

        self.model = {
            "Lumina": 0
        }
        self.model_list = [
            Lumina
        ]        
                        
    def main(self):
        chatbot = self.model_list[self.model[bot]]
        while True:
            user_input = input("You> ")
            if "quit" in user_input:
                response = random.choice(["Bye", "See you later", "Tata"])
                print("Bot>", response)
                break
            response=chatbot.get_response(user_input, ResponseFile)          
            
if __name__ == "__main__":
    mainloop = MainLoop()
    mainloop.main()                    
                    
        