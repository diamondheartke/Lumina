import sys
import time
import random

class TokenSimulation:
    def __init__(self):
        pass

    def Text(self, text, min_chunk=2, max_chunk=8, min_delay=0.02, max_delay=0.7):
        l = 0
        while l < len(text):
            chunk_size = random.randint(min_chunk, max_chunk)
            chunk = text[l:l+chunk_size]
            sys.stdout.write(chunk)
            sys.stdout.flush()
            l += chunk_size
            time.sleep(random.uniform(min_delay, max_delay))
        return ""                   
              