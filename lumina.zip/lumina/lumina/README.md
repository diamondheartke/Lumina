# Lumina

Lumina - an AI powered platform with a virtual tutor and timetable generator

Name: Lumina - Light from Beyond

Tagline: 'Lighting the Way to Smarter Learning'

Brand defenition: Intelligent guidance that illuminates learning, cuts through confusuion and sparks curiosity in every student.

Lumina - The light from Beyond, 
'Lighting the way to smarter learning'
